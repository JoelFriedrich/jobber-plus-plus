// content.js — Jobber++ orchestrator

(function () {
  if (!window.location.hostname.includes('getjobber.com')) return;
  if (window.__JPP_INIT__) return;
  window.__JPP_INIT__ = true;

  function init() {
    initShortcuts();   // keyboard shortcuts — global, all pages
    initWeather();     // weather badges + current conditions widget
    initPresets();     // schedule view preset buttons
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
