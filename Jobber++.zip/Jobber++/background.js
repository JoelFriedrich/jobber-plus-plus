// background.js — Jobber++ service worker

// ─── Weather state ────────────────────────────────────────────────────────────
let hourlyForecastUrl = null;
let currentConditionsCache = null;
let currentConditionsFetchTime = 0;
const CURRENT_CONDITIONS_TTL = 30 * 60 * 1000;

// ─── License state (Stripe-ready) ────────────────────────────────────────────
// Wire up VALIDATE_LICENSE once your Stripe + Supabase backend is live.
// The popup checks this on open; features work freely until you flip GATE_FEATURES.
const GATE_FEATURES = false; // set true when monetization is live

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {

  // ── Weather: coords ──────────────────────────────────────────────────────
  if (message.type === 'GET_COORDS') {
    chrome.storage.local.get('weatherLocation', (result) => {
      const loc = result.weatherLocation;
      const lat = parseFloat(loc?.lat);
      const lon = parseFloat(loc?.lon);
      if (!loc || isNaN(lat) || isNaN(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
        sendResponse({ error: 'NO_LOCATION_SET' });
      } else {
        sendResponse({ coords: { lat: lat.toFixed(4), lon: lon.toFixed(4) } });
      }
    });
    return true;
  }

  // ── Weather: current conditions ──────────────────────────────────────────
  if (message.type === 'GET_CURRENT_CONDITIONS') {
    const now = Date.now();
    if (currentConditionsCache && (now - currentConditionsFetchTime < CURRENT_CONDITIONS_TTL)) {
      sendResponse({ conditions: currentConditionsCache });
      return true;
    }

    chrome.storage.local.get('weatherLocation', (result) => {
      const loc = result.weatherLocation;
      // Validate coords are numeric before interpolating into URL
      const lat = parseFloat(loc?.lat);
      const lon = parseFloat(loc?.lon);
      if (!loc || isNaN(lat) || isNaN(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
        sendResponse({ error: 'NO_LOCATION_SET' }); return;
      }

      const doHourlyFetch = (url) => {
        fetch(url, { headers: { 'User-Agent': 'JobberPlusPlus/1.0' } })
          .then(res => { if (!res.ok) throw new Error(`NOAA hourly: ${res.status}`); return res.json(); })
          .then(data => {
            const periods = data.properties.periods;
            const nowIso = new Date().toISOString();
            const current = periods.find(p => p.startTime <= nowIso && nowIso < p.endTime) || periods[0];
            currentConditionsCache = {
              temp: current.temperature,
              shortForecast: current.shortForecast,
              windSpeed: current.windSpeed,
              windDirection: current.windDirection,
              rain: current.probabilityOfPrecipitation?.value ?? 0
            };
            currentConditionsFetchTime = Date.now();
            sendResponse({ conditions: currentConditionsCache });
          })
          .catch(err => sendResponse({ error: err.message }));
      };

      if (hourlyForecastUrl) {
        doHourlyFetch(hourlyForecastUrl);
      } else {
        fetch(`https://api.weather.gov/points/${loc.lat},${loc.lon}`, {
          headers: { 'User-Agent': 'JobberPlusPlus/1.0' }
        })
          .then(res => { if (!res.ok) throw new Error(`NOAA points: ${res.status}`); return res.json(); })
          .then(data => { hourlyForecastUrl = data.properties.forecastHourly; doHourlyFetch(hourlyForecastUrl); })
          .catch(err => sendResponse({ error: err.message }));
      }
    });
    return true;
  }

  // ── Weather: save city ───────────────────────────────────────────────────
  if (message.type === 'SAVE_CITY') {
    const city = (message.city || '').trim();
    if (!city) { sendResponse({ error: 'Empty city name' }); return true; }

    hourlyForecastUrl = null;
    currentConditionsCache = null;
    currentConditionsFetchTime = 0;

    fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`)
      .then(res => { if (!res.ok) throw new Error(`Geocoding: ${res.status}`); return res.json(); })
      .then(data => {
        const result = data.results?.[0];
        if (!result) throw new Error(`City not found: "${city}"`);
        const loc = {
          lat: result.latitude.toFixed(4),
          lon: result.longitude.toFixed(4),
          label: `${result.name}${result.admin1 ? ', ' + result.admin1 : ''}, ${result.country}`
        };
        chrome.storage.local.set({ weatherLocation: loc }, () => sendResponse({ success: true, loc }));
      })
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  // ── Weather: clear location ──────────────────────────────────────────────
  if (message.type === 'CLEAR_LOCATION') {
    hourlyForecastUrl = null;
    currentConditionsCache = null;
    currentConditionsFetchTime = 0;
    chrome.storage.local.remove('weatherLocation', () => sendResponse({ success: true }));
    return true;
  }

  // ── License: validate (Stripe-ready stub) ────────────────────────────────
  // When GATE_FEATURES is true, swap this stub for a real Supabase fetch:
  //
  // if (message.type === 'VALIDATE_LICENSE') {
  //   fetch('https://your-netlify-fn.netlify.app/.netlify/functions/validate-license', {
  //     method: 'POST',
  //     headers: { 'Content-Type': 'application/json' },
  //     body: JSON.stringify({ email: message.email, token: message.token })
  //   })
  //   .then(r => r.json())
  //   .then(data => sendResponse({ valid: data.valid, plan: data.plan }))
  //   .catch(() => sendResponse({ valid: false }));
  //   return true;
  // }

  if (message.type === 'CHECK_ACCESS') {
    // Returns true while GATE_FEATURES is off (open beta / development)
    sendResponse({ hasAccess: !GATE_FEATURES });
    return true;
  }

});
