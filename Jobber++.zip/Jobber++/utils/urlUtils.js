// utils/urlUtils.js

function hasStaticDate(url) {
  return /\/schedule\/(day|week|month)\/\d{4}\/\d{1,2}\/\d{1,2}/.test(url);
}

function substituteToday(url) {
  return url.replace(
    /\/schedule\/(day|week|month)\/\d{4}\/\d{1,2}\/\d{1,2}/,
    '/schedule/$1/today'
  );
}

function generatePresetName(url) {
  const viewMatch = url.match(/\/schedule\/(day|week|month)/i);
  const view = viewMatch
    ? viewMatch[1].charAt(0).toUpperCase() + viewMatch[1].slice(1)
    : 'Schedule';

  try {
    const urlObj = new URL(url);
    const parts = [view];

    const apptTypes = urlObj.searchParams.get('appointmentTypes');
    if (apptTypes) {
      try {
        const parsed = JSON.parse(decodeURIComponent(apptTypes));
        if (Array.isArray(parsed) && parsed.length > 0) parts.push(parsed.join(', '));
      } catch { /* not JSON */ }
    }

    const unscheduled = urlObj.searchParams.get('unscheduled');
    if (unscheduled === 'on') parts.push('Unscheduled');

    const map = urlObj.searchParams.get('map');
    if (map && map !== 'hidden') parts.push('Map');

    return parts.join(' · ');
  } catch {
    return view;
  }
}
