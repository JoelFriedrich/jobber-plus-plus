// utils/storage.js

const PRESETS_KEY = 'jobber_view_presets';

// ─── Presets (sync) ───────────────────────────────────────────────────────────

async function getPresets() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(PRESETS_KEY, (result) => {
      resolve(result[PRESETS_KEY] || []);
    });
  });
}

async function savePresets(presets) {
  return new Promise((resolve) => {
    chrome.storage.sync.set({ [PRESETS_KEY]: presets }, resolve);
  });
}

async function addPreset(preset) {
  const presets = await getPresets();
  const newPreset = {
    id: Date.now().toString(),
    name: preset.name,
    url: preset.url,
    isHistorical: preset.isHistorical || false,
    createdAt: new Date().toISOString()
  };
  presets.push(newPreset);
  await savePresets(presets);
  return newPreset;
}

async function updatePreset(id, changes) {
  const presets = await getPresets();
  const index = presets.findIndex(p => p.id === id);
  if (index === -1) return false;
  presets[index] = { ...presets[index], ...changes };
  await savePresets(presets);
  return true;
}

async function deletePreset(id) {
  const presets = await getPresets();
  await savePresets(presets.filter(p => p.id !== id));
}

async function reorderPresets(orderedIds) {
  const presets = await getPresets();
  const map = Object.fromEntries(presets.map(p => [p.id, p]));
  await savePresets(orderedIds.map(id => map[id]).filter(Boolean));
}

// ─── Weather (local) ──────────────────────────────────────────────────────────

async function getWeatherLocation() {
  return new Promise((resolve) => {
    chrome.storage.local.get('weatherLocation', (r) => resolve(r.weatherLocation || null));
  });
}

async function getConditionsStyle() {
  return new Promise((resolve) => {
    chrome.storage.local.get('conditionsStyle', (r) => resolve(r.conditionsStyle || 'compact'));
  });
}
