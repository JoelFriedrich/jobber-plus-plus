# Jobber++ — Chrome Web Store Listing

---

## SHORT DESCRIPTION (132 chars max)

Keyboard shortcuts, schedule view presets, and live weather for Jobber. Built for field service pros.

---

## FULL DESCRIPTION

**Jobber++ makes your Jobber workflow faster, smarter, and more context-aware — without ever leaving the page.**

Built by a field service business owner who uses Jobber every day, Jobber++ adds three features that should have been there all along.

---

### ⚡ Keyboard Shortcuts

Stop clicking through menus for things you do a hundred times a day.

- **⌘⇧S** — Save the current record
- **⌘⇧E** — Edit the current record
- **⌘⇧O** — Trigger the primary action button
- **⌘⇧C** — Quick-create a new client
- **⌘⇧R** — Quick-create a new request
- **⌘⇧M / W / D** — Switch schedule to Month, Week, or Day view
- **⌘⇧U** — Toggle the unscheduled panel
- **⌘⇧K** — Toggle the map view

All shortcuts show a subtle on-screen toast confirmation so you always know they fired.

---

### 🗂 Schedule View Presets

Jobber's schedule URL carries a lot of state — view type, filters, appointment types, map visibility. Jobber++ lets you save any combination as a named button that appears directly in the schedule toolbar.

- One click to save any schedule view as a preset
- Smart date handling: choose whether a saved view always shows today, or stays locked to a specific historical date
- Preset buttons live natively in the Jobber UI — styled to match, not bolted on
- Drag to reorder, edit names and URLs after the fact, delete any time
- Presets sync across devices via Chrome sync

---

### ☀️ Weather Forecast Overlay

Field service runs outside. Jobber++ surfaces the forecast right where you're already planning your day.

- Weather emoji appear on each day in month, week, and day schedule views
- Live current conditions display in the schedule toolbar
- Hover any day for a detailed tooltip: high/low temps, rain probability, wind speed
- Set your location once — it just works

---

### 🔒 Privacy First

Jobber++ does not collect, transmit, or sell any personal data. Your Jobber session, your schedule data, and your location are never sent anywhere except the NOAA weather API (US only) to fetch forecast data. Everything else stays on your device.

---

### Notes

- Weather uses the free NOAA API (US locations only)
- Keyboard shortcuts use ⌘ on Mac and Ctrl on Windows/Linux
- Works on secure.getjobber.com only

---
---

# PRIVACY POLICY

**Jobber++ Chrome Extension — Privacy Policy**
Last updated: May 2026

---

## What data Jobber++ accesses

**Location data (city/coordinates)**
If you use the Weather feature, you may optionally enter a city name. Jobber++ uses the Open-Meteo geocoding API to convert that city name to latitude/longitude coordinates. Those coordinates are stored locally on your device using Chrome's storage API and are used solely to fetch weather forecasts from the NOAA Weather API (api.weather.gov). Your location is never transmitted to any server operated by Jobber++ or its developer.

**Schedule view URLs**
If you use the View Presets feature, Jobber++ saves Jobber schedule URLs that you choose to save. These URLs are stored using Chrome's sync storage, which means they may sync across your Chrome-signed-in devices via Google's infrastructure. No URL data is sent to any server operated by Jobber++ or its developer.

**Keyboard activity**
Jobber++ listens for specific keyboard shortcuts on Jobber pages only (secure.getjobber.com). No keystrokes are logged, stored, or transmitted. The extension only responds to the exact key combinations listed in the extension popup.

---

## What data Jobber++ does NOT collect

- No personal information (name, email, address)
- No Jobber account credentials or session tokens
- No Jobber client, job, invoice, or business data
- No browsing history outside of secure.getjobber.com
- No analytics, crash reports, or usage tracking
- No advertising identifiers

---

## Third-party services used

| Service | Purpose | Data sent | Privacy policy |
|---|---|---|---|
| NOAA Weather API (api.weather.gov) | Fetch weather forecasts | Your latitude/longitude | weather.gov |
| Open-Meteo Geocoding API | Convert city name to coordinates | City name you enter | open-meteo.com |

No other third-party services are used. No data brokers, analytics platforms, or advertising networks receive any data from this extension.

---

## Data storage

All user data (saved presets, location) is stored using Chrome's built-in storage APIs:
- `chrome.storage.local` — location coordinates (device only)
- `chrome.storage.sync` — view presets (synced across your Chrome devices via Google)

You can clear all stored data at any time by removing the extension or clearing extension storage in Chrome settings.

---

## Children's privacy

This extension is not directed at children under 13 and does not knowingly collect data from children.

---

## Changes to this policy

If this policy changes materially, the extension version number will be updated and the change will be noted in the Chrome Web Store changelog.

---

## Contact

Questions about this privacy policy? Email: joelfriedrichdev+jobberpp@gmail.com
