// modules/shortcuts.js

const SHORTCUTS = {
  save: {
    label: 'Save', keys: '⌘ ⇧ S', keysWin: 'Ctrl+Shift+S',
    description: 'Save the current record',
    action: 'clickByText',
    target: ['Save', 'Save changes', 'Save & close', 'Save invoice', 'Save job', 'Save quote'],
    scope: 'global',
  },
  edit: {
    label: 'Edit', keys: '⌘ ⇧ E', keysWin: 'Ctrl+Shift+E',
    description: 'Edit the current record',
    action: 'clickByText', target: ['Edit'], scope: 'global',
  },
  primaryAction: {
    label: 'Primary action', keys: '⌘ ⇧ O', keysWin: 'Ctrl+Shift+O',
    description: 'Click the primary green button',
    action: 'clickPrimary',
    target: 'amVSJ50CiOo-',
    exclude: ['delete', 'remove', 'archive', 'void', 'cancel'],
    scope: 'global',
  },
  newClient: {
    label: 'New client', keys: '⌘ ⇧ C', keysWin: 'Ctrl+Shift+C',
    description: 'Quick-create a new client',
    action: 'navigate',
    target: 'https://secure.getjobber.com/clients/new?tracking_origin=quick_create',
    scope: 'global',
  },
  newRequest: {
    label: 'New request', keys: '⌘ ⇧ R', keysWin: 'Ctrl+Shift+R',
    description: 'Quick-create a new request',
    action: 'navigate',
    target: 'https://secure.getjobber.com/requests/new?source=quick_create',
    scope: 'global',
  },
  scheduleMonth: {
    label: 'Month view', keys: '⌘ ⇧ M', keysWin: 'Ctrl+Shift+M',
    description: 'Switch schedule to month view',
    action: 'clickRadio', target: 'month', scope: 'schedule',
  },
  scheduleWeek: {
    label: 'Week view', keys: '⌘ ⇧ L', keysWin: 'Ctrl+Shift+L',
    description: 'Switch schedule to week view',
    action: 'clickRadio', target: 'week', scope: 'schedule',
  },
  scheduleDay: {
    label: 'Day view', keys: '⌘ ⇧ D', keysWin: 'Ctrl+Shift+D',
    description: 'Switch schedule to day view',
    action: 'clickRadio', target: 'day', scope: 'schedule',
  },
  scheduleUnscheduled: {
    label: 'Toggle unscheduled', keys: '⌘ ⇧ U', keysWin: 'Ctrl+Shift+U',
    description: 'Toggle unscheduled appointments panel',
    action: 'clickByAriaLabel', target: 'Unscheduled appointments', scope: 'schedule',
  },
  scheduleMap: {
    label: 'Toggle map', keys: '⌘ ⇧ K', keysWin: 'Ctrl+Shift+K',
    description: 'Toggle map view',
    action: 'clickByAriaLabel', target: 'Toggle Map', scope: 'schedule',
  },
};

const KEY_MAP = {
  'meta+shift+s': 'save',
  'meta+shift+e': 'edit',
  'meta+shift+o': 'primaryAction',
  'meta+shift+c': 'newClient',
  'meta+shift+r': 'newRequest',
  'meta+shift+m': 'scheduleMonth',
  'meta+shift+l': 'scheduleWeek',
  'meta+shift+d': 'scheduleDay',
  'meta+shift+u': 'scheduleUnscheduled',
  'meta+shift+k': 'scheduleMap',
};

function initShortcuts() {
  document.addEventListener('keydown', (e) => {
    const key = [
      e.metaKey  ? 'meta'  : null,
      e.ctrlKey  ? 'ctrl'  : null,
      e.shiftKey ? 'shift' : null,
      e.key.length === 1 ? e.key.toLowerCase() : e.key,
    ].filter(Boolean).join('+');

    const commandName = KEY_MAP[key];
    if (!commandName) return;
    const shortcut = SHORTCUTS[commandName];
    if (!shortcut) return;

    e.preventDefault();
    executeShortcut(shortcut);
  });
}

function executeShortcut(shortcut) {
  if (shortcut.scope === 'schedule' && !window.location.pathname.startsWith('/schedule')) {
    showToast('⚠️ This shortcut only works on the Schedule page.', 'warn');
    return;
  }
  switch (shortcut.action) {
    case 'clickByText':      handleClickByText(shortcut);      break;
    case 'clickByAriaLabel': handleClickByAriaLabel(shortcut); break;
    case 'clickRadio':       handleClickRadio(shortcut);       break;
    case 'clickPrimary':     handleClickPrimary(shortcut);     break;
    case 'navigate':         handleNavigate(shortcut);         break;
  }
}

function handleClickByText(shortcut) {
  const targets = shortcut.target.map(t => t.toLowerCase());
  const candidates = Array.from(
    document.querySelectorAll('button, a, [role="button"], input[type="submit"], span')
  );
  const matches = candidates.filter(el => {
    const text = (el.innerText || el.value || el.getAttribute('aria-label') || '').trim().toLowerCase();
    return targets.some(t => text === t || text.startsWith(t));
  });
  if (matches.length === 0) { showToast(`⚠️ No "${shortcut.label}" button found.`, 'warn'); return; }
  const target = matches.find(el => isVisible(el) && !el.disabled) || matches[0];
  target.click();
  showToast(`✓ ${shortcut.label}`, 'success');
}

function handleClickByAriaLabel(shortcut) {
  const el = document.querySelector(`[aria-label="${shortcut.target}"]`);
  if (!el) { showToast(`⚠️ "${shortcut.label}" not found.`, 'warn'); return; }
  el.click();
  showToast(`✓ ${shortcut.label}`, 'success');
}

function handleClickRadio(shortcut) {
  const el = document.querySelector(`input[type="radio"][value="${shortcut.target}"]`);
  if (!el) { showToast(`⚠️ "${shortcut.label}" not found.`, 'warn'); return; }
  el.click();
  showToast(`✓ ${shortcut.label}`, 'success');
}

function handleClickPrimary(shortcut) {
  const exclude = shortcut.exclude || [];
  const candidates = Array.from(document.querySelectorAll('button.amVSJ50CiOo-.TrzCxs3OEpM-'));
  const safe = candidates.filter(el => {
    if (!isVisible(el) || el.disabled) return false;
    const text = (el.innerText || el.getAttribute('aria-label') || '').trim().toLowerCase();
    return !exclude.some(word => text.includes(word));
  });
  if (safe.length === 0) { showToast('⚠️ No primary action button found.', 'warn'); return; }
  const modal = document.querySelector('[role="dialog"], [role="alertdialog"]');
  const target = modal
    ? safe.find(el => modal.contains(el)) || safe[safe.length - 1]
    : safe[safe.length - 1];
  const label = (target.innerText || target.getAttribute('aria-label') || 'Primary action').trim();
  target.click();
  showToast(`✓ ${label}`, 'success');
}

function handleNavigate(shortcut) {
  showToast(`✓ ${shortcut.label}`, 'success');
  window.location.href = shortcut.target;
}

function isVisible(el) {
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0 &&
    window.getComputedStyle(el).visibility !== 'hidden' &&
    window.getComputedStyle(el).display !== 'none';
}

function showToast(message, type = 'success') {
  document.getElementById('jpp-toast')?.remove();
  const toast = document.createElement('div');
  toast.id = 'jpp-toast';
  toast.textContent = message;
  const colors = {
    success: { bg: '#1a1a2e', border: '#8ACC33', text: '#8ACC33' },
    warn:    { bg: '#1a1a2e', border: '#facc15', text: '#facc15' },
  };
  const c = colors[type] || colors.success;
  Object.assign(toast.style, {
    position: 'fixed', bottom: '24px', right: '24px', zIndex: '99999',
    padding: '10px 16px', borderRadius: '8px', fontSize: '13px',
    fontFamily: 'monospace', fontWeight: '600', letterSpacing: '0.05em',
    background: c.bg, border: `1px solid ${c.border}`, color: c.text,
    boxShadow: '0 4px 24px rgba(0,0,0,0.4)', opacity: '0',
    transition: 'opacity 0.15s ease', pointerEvents: 'none',
  });
  document.body.appendChild(toast);
  requestAnimationFrame(() => (toast.style.opacity = '1'));
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 200);
  }, 2000);
}

// Expose for popup
if (typeof window !== 'undefined') window.JPP_SHORTCUTS = SHORTCUTS;
