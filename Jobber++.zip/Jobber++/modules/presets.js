// modules/presets.js

const TOOLBAR_ID = 'jpp-presets-toolbar';
const POLL_INTERVAL = 400;
const POLL_TIMEOUT  = 30000;

// ─── Single injection lock ────────────────────────────────────────────────────
// Prevents concurrent inject attempts from racing each other.
let _injecting = false;

// ─── Main loop ────────────────────────────────────────────────────────────────
// One setInterval owns the entire lifecycle — initial injection AND
// re-injection after SPA navigation. No MutationObserver, no competing promises.

function initPresets() {
  if (!window.location.pathname.startsWith('/schedule')) return;

  const started = Date.now();

  const loop = setInterval(async () => {

    // Give up after timeout
    if (Date.now() - started > POLL_TIMEOUT) {
      clearInterval(loop);
      console.warn('[JPP Presets] Gave up waiting for filter panel.');
      return;
    }

    const filterPanel    = document.querySelector('[data-testid="filter-panel"]');
    const bannerContainer = filterPanel?.querySelector('._bannerAndModalContainer_ztmye_21');
    const toolbarExists  = !!document.getElementById(TOOLBAR_ID);

    // Panel present and toolbar already there — nothing to do
    if (filterPanel && bannerContainer && toolbarExists) return;

    // Panel not ready yet — keep waiting
    if (!filterPanel || !bannerContainer) return;

    // Panel ready but toolbar missing — inject (with lock to prevent double-fire)
    if (!_injecting) {
      _injecting = true;
      try {
        await injectPresetsToolbar(filterPanel, bannerContainer);
      } finally {
        _injecting = false;
      }
    }

  }, POLL_INTERVAL);

  // Live-update buttons when storage changes (popup saved/deleted a preset)
  chrome.storage.onChanged.addListener((changes) => {
    if (changes['jobber_view_presets']) {
      const toolbar = document.getElementById(TOOLBAR_ID);
      if (toolbar) renderPresetButtons(toolbar, changes['jobber_view_presets'].newValue || []);
    }
  });
}

// ─── Injection ────────────────────────────────────────────────────────────────

async function injectPresetsToolbar(filterPanel, bannerContainer) {
  // Re-check inside the lock — another tick may have beaten us
  if (document.getElementById(TOOLBAR_ID)) return;

  const presets = await getPresets();

  // Check once more after the async storage read — DOM could have changed
  if (document.getElementById(TOOLBAR_ID)) return;
  if (!document.contains(bannerContainer))  return; // panel was torn down mid-await

  const toolbar = document.createElement('div');
  toolbar.id        = TOOLBAR_ID;
  toolbar.className = 'jpp-presets-toolbar';
  renderPresetButtons(toolbar, presets);
  filterPanel.insertBefore(toolbar, bannerContainer);
}

// ─── Render ───────────────────────────────────────────────────────────────────

function renderPresetButtons(toolbar, presets) {
  toolbar.innerHTML = '';
  if (presets.length === 0) {
    const hint = document.createElement('span');
    hint.className = 'jpp-preset-hint';
    hint.textContent = 'No presets yet — save a view from the Jobber++ popup';
    toolbar.appendChild(hint);
    return;
  }
  presets.forEach(preset => {
    const btn = document.createElement('button');
    btn.className      = 'jpp-preset-btn';
    btn.dataset.presetId = preset.id;
    btn.title          = preset.url;
    btn.textContent    = preset.isHistorical ? `📅 ${preset.name}` : preset.name;
    btn.addEventListener('click', () => { window.location.href = preset.url; });
    toolbar.appendChild(btn);
  });
}

// ─── Message listener ─────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'GET_CURRENT_URL') {
    sendResponse({ url: window.location.href });
  }
  if (message.type === 'REFRESH_TOOLBAR') {
    const toolbar = document.getElementById(TOOLBAR_ID);
    if (toolbar) getPresets().then(presets => renderPresetButtons(toolbar, presets));
  }
});
