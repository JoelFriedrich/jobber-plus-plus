// modules/weather.js

const WEATHER_MAX_CONDITION_CHARS = 20;

// ─── Precipitation probability thresholds ─────────────────────────────────────
const PRECIP_LOW = 25;  // 0–25%: dominant icon only
const PRECIP_MED = 59;  // 26–59%: dominant + faint risk icon
                        // 60%+: risk icon is the primary

// ─── Emoji mapping ────────────────────────────────────────────────────────────

/**
 * Full condition → emoji including non-precip.
 * Operates on the DOMINANT part of the forecast (before "then"/"and").
 */
function conditionToEmoji(shortForecast) {
  if (!shortForecast) return '🌡️';
  const f = shortForecast.toLowerCase();
  if (f.includes('thunderstorm') || f.includes('thunder')) return '⛈️';
  if (f.includes('tornado'))   return '🌪️';
  if (f.includes('blizzard'))  return '❄️';
  if (f.includes('snow') || f.includes('sleet') || f.includes('flurr')) return '🌨️';
  if (f.includes('freezing') || f.includes('ice')) return '🧊';
  if (f.includes('fog') || f.includes('haze') || f.includes('mist'))    return '🌫️';
  if (f.includes('rain') || f.includes('shower') || f.includes('drizzle')) return '🌧️';
  if (f.includes('partly') && (f.includes('cloud') || f.includes('sun'))) return '⛅';
  if (f.includes('mostly cloud') || f.includes('overcast')) return '☁️';
  if (f.includes('cloud'))  return '🌥️';
  if (f.includes('sunny') || f.includes('clear')) return '☀️';
  if (f.includes('wind') || f.includes('breezy') || f.includes('blustery')) return '💨';
  if (f.includes('hot'))   return '🌡️';
  if (f.includes('cold') || f.includes('frigid')) return '🥶';
  return '🌡️';
}

/**
 * Precipitation-ONLY emoji from a forecast string.
 * Returns null for non-precip conditions (wind, fog, hot, etc.)
 * Used exclusively for the secondary risk icon.
 */
function precipToEmoji(forecastStr) {
  if (!forecastStr) return null;
  const f = forecastStr.toLowerCase();
  if (f.includes('thunderstorm') || f.includes('thunder')) return '⛈️';
  if (f.includes('blizzard'))                              return '❄️';
  if (f.includes('snow') || f.includes('flurr'))           return '🌨️';
  if (f.includes('sleet'))                                 return '🌨️';
  if (f.includes('freezing rain') || f.includes('freezing drizzle')) return '🧊';
  if (f.includes('rain') || f.includes('shower') || f.includes('drizzle')) return '🌧️';
  return null;
}

/**
 * Resolves primary and secondary weather icons based on forecast + rain probability.
 *
 * 0–25%:   primary = dominant condition, no secondary
 * 26–59%:  primary = dominant condition, secondary = precip risk icon at 40% opacity
 * 60%+:    primary = precip risk icon (it IS the story), no secondary
 *
 * "Dominant" = forecast text before "then" / "and" / ","
 * "Risk"     = scans full string for precip keywords
 */
function resolveWeatherIcons(shortForecast, rainPct) {
  const pct = rainPct ?? 0;

  const dominantPart = (shortForecast || '')
    .replace(/\s+(then|and|with)\s+.*/i, '')
    .replace(/,.*/, '')
    .trim();

  const primary  = conditionToEmoji(dominantPart);
  const riskIcon = precipToEmoji(shortForecast); // scans full string for any precip mention

  if (pct <= PRECIP_LOW) {
    return { primary, secondary: null, secondaryOpacity: 0 };
  }

  if (pct <= PRECIP_MED) {
    // Only show secondary if there's a specific precip type — don't show faint icon for clear/wind days
    return { primary, secondary: riskIcon, secondaryOpacity: 0.4 };
  }

  // 60%+ — precip is the dominant story
  const highRiskIcon = riskIcon || conditionToEmoji(shortForecast);
  return { primary: highRiskIcon, secondary: null, secondaryOpacity: 0 };
}

/**
 * Truncates a condition string to a short, readable label.
 * "Mostly Cloudy then Slight Chance Rain Showers" → "Mostly Cloudy"
 */
function truncateCondition(str) {
  if (!str) return '';
  const trimmed = str.replace(/\s+(then|and|with)\s+.*/i, '').replace(/,.*/, '').trim();
  if (trimmed.length <= WEATHER_MAX_CONDITION_CHARS) return trimmed;
  return trimmed.substring(0, WEATHER_MAX_CONDITION_CHARS).trim() + '…';
}

// ─── State ────────────────────────────────────────────────────────────────────

let forecastCache = {};
let gridForecastUrl = null;
let userCoords = null;
let fetchInProgress = false;
let lastFetchTime = 0;
let currentConditionsInterval = null;
let weatherTooltip = null;
const CACHE_TTL = 60 * 60 * 1000;

// ─── Coords ───────────────────────────────────────────────────────────────────

async function getCoords() {
  if (userCoords) return userCoords;
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: 'GET_COORDS' }, (response) => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if (response?.error) return reject(new Error(response.error));
      if (response?.coords) { userCoords = response.coords; return resolve(userCoords); }
      reject(new Error('No coords returned'));
    });
  });
}

// ─── Forecast fetch ───────────────────────────────────────────────────────────

async function fetchForecast() {
  if (fetchInProgress) return;
  const now = Date.now();
  if (now - lastFetchTime < CACHE_TTL && Object.keys(forecastCache).length > 0) return;

  fetchInProgress = true;
  try {
    const coords = await getCoords();
    if (!gridForecastUrl) {
      const res = await fetch(`https://api.weather.gov/points/${coords.lat},${coords.lon}`, {
        headers: { 'User-Agent': 'JobberPlusPlus/1.0' }
      });
      if (!res.ok) throw new Error(`NOAA points error: ${res.status}`);
      const data = await res.json();
      gridForecastUrl = data.properties.forecast;
    }
    const forecastRes = await fetch(gridForecastUrl, {
      headers: { 'User-Agent': 'JobberPlusPlus/1.0' }
    });
    if (!forecastRes.ok) throw new Error(`NOAA forecast error: ${forecastRes.status}`);
    const forecastData = await forecastRes.json();

    const tempMap = {};
    for (const period of forecastData.properties.periods) {
      const dateStr = period.startTime.substring(0, 10);
      if (!tempMap[dateStr]) {
        tempMap[dateStr] = {
          high: null, low: null, rain: null,
          wind: '', windDir: '',
          primary: null, secondary: null, secondaryOpacity: 0,
          shortForecast: null, detailedForecast: ''
        };
      }
      const entry = tempMap[dateStr];
      const rain = period.probabilityOfPrecipitation?.value ?? 0;
      if (period.isDaytime) {
        entry.high = period.temperature;
        entry.rain = rain;
        entry.wind = period.windSpeed || '';
        entry.windDir = period.windDirection || '';
        entry.shortForecast = period.shortForecast;
        entry.detailedForecast = period.detailedForecast || '';
        const icons = resolveWeatherIcons(period.shortForecast, rain);
        entry.primary = icons.primary;
        entry.secondary = icons.secondary;
        entry.secondaryOpacity = icons.secondaryOpacity;
        // Keep legacy .emoji for tooltip title
        entry.emoji = icons.primary;
      } else {
        entry.low = period.temperature;
        if (entry.rain === null) entry.rain = rain;
        if (!entry.primary) {
          const icons = resolveWeatherIcons(period.shortForecast, rain);
          entry.primary = icons.primary;
          entry.secondary = icons.secondary;
          entry.secondaryOpacity = icons.secondaryOpacity;
          entry.emoji = icons.primary;
          entry.shortForecast = period.shortForecast;
        }
      }
    }
    forecastCache = tempMap;
    lastFetchTime = now;
  } catch (err) {
    if (err.message !== 'NO_LOCATION_SET') console.warn('[JPP Weather] Forecast fetch failed:', err.message);
  } finally {
    fetchInProgress = false;
  }
}

// ─── Tooltip ─────────────────────────────────────────────────────────────────

function getTooltip() {
  if (!weatherTooltip) {
    weatherTooltip = document.createElement('div');
    weatherTooltip.id = 'jpp-weather-tooltip';
    weatherTooltip.style.cssText = `
      position:fixed;z-index:99999;background:#1a1a2e;color:#f0f0f0;
      border-radius:8px;padding:10px 14px;font-size:13px;line-height:1.6;
      pointer-events:none;opacity:0;transition:opacity 0.15s ease;
      box-shadow:0 4px 16px rgba(0,0,0,0.4);min-width:180px;max-width:240px;
      font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
    `;
    document.body.appendChild(weatherTooltip);
  }
  return weatherTooltip;
}

function setTooltipRow(grid, label, value, color) {
  const lEl = document.createElement('span');
  lEl.style.color = '#aaa';
  lEl.textContent = label;
  const vEl = document.createElement('span');
  vEl.textContent = value;
  if (color) vEl.style.color = color;
  grid.appendChild(lEl);
  grid.appendChild(vEl);
}

function buildTooltipBase(tip, titleText) {
  tip.innerHTML = '';
  const header = document.createElement('div');
  header.style.cssText = 'font-weight:600;font-size:14px;margin-bottom:6px;border-bottom:1px solid rgba(255,255,255,0.15);padding-bottom:5px;';
  header.textContent = titleText;
  const grid = document.createElement('div');
  grid.style.cssText = 'display:grid;grid-template-columns:auto 1fr;gap:2px 10px;';
  tip.appendChild(header);
  tip.appendChild(grid);
  return grid;
}

function showWeatherTooltip(el, data) {
  const tip = getTooltip();
  const rainPct = data.rain !== null ? `${data.rain}%` : 'N/A';
  const high = data.high !== null ? `${data.high}°F` : 'N/A';
  const low  = data.low  !== null ? `${data.low}°F`  : 'N/A';
  const wind = data.wind ? `${data.wind} ${data.windDir}`.trim() : 'N/A';
  const rainColor = data.rain >= 60 ? '#f87171' : data.rain >= 26 ? '#fbbf24' : '#86efac';
  const title = `${data.primary}${data.secondary ? ' ' + data.secondary : ''} ${data.shortForecast || ''}`;
  const grid = buildTooltipBase(tip, title);
  setTooltipRow(grid, 'High', high);
  setTooltipRow(grid, 'Low', low);
  setTooltipRow(grid, 'Rain', rainPct, rainColor);
  setTooltipRow(grid, 'Wind', wind);
  tip.style.opacity = '1';
  positionWeatherTooltip(el);
}

function showCurrentTooltip(el, conditions) {
  const tip = getTooltip();
  const wind = conditions.windSpeed ? `${conditions.windSpeed} ${conditions.windDirection || ''}`.trim() : 'N/A';
  const rain = conditions.rain !== null ? `${conditions.rain}%` : 'N/A';
  const rainColor = conditions.rain >= 60 ? '#f87171' : conditions.rain >= 26 ? '#fbbf24' : '#86efac';
  const grid = buildTooltipBase(tip, 'Current Conditions');
  setTooltipRow(grid, 'Temp', `${conditions.temp}°F`);
  setTooltipRow(grid, 'Feels like', conditions.shortForecast || '');
  setTooltipRow(grid, 'Rain', rain, rainColor);
  setTooltipRow(grid, 'Wind', wind);
  tip.style.opacity = '1';
  positionWeatherTooltip(el);
}

function positionWeatherTooltip(el) {
  const tip = getTooltip();
  const rect = el.getBoundingClientRect();
  const tipW = 240, tipH = 120;
  let left = rect.left;
  let top  = rect.bottom + 6;
  if (left + tipW > window.innerWidth - 10)  left = window.innerWidth - tipW - 10;
  if (top  + tipH > window.innerHeight - 10) top  = rect.top - tipH - 6;
  tip.style.left = `${left}px`;
  tip.style.top  = `${top}px`;
}

function hideWeatherTooltip() {
  getTooltip().style.opacity = '0';
}

// ─── Badge injection ──────────────────────────────────────────────────────────

function injectWeatherBadge(spanEl, dateStr, data) {
  if (spanEl.querySelector('.jpp-weather-badge')) return;

  const wrapper = document.createElement('span');
  wrapper.className = 'jpp-weather-badge';
  wrapper.style.cssText = 'cursor:default;font-style:normal;font-size:0.9em;display:inline;white-space:nowrap;';

  // Primary icon — always full opacity
  const primaryEl = document.createElement('span');
  primaryEl.textContent = ` ${data.primary}`;

  wrapper.appendChild(primaryEl);

  // Secondary risk icon — only if present, rendered at reduced opacity
  if (data.secondary) {
    const secondaryEl = document.createElement('span');
    secondaryEl.textContent = data.secondary;
    secondaryEl.style.opacity = String(data.secondaryOpacity ?? 0.4);
    wrapper.appendChild(secondaryEl);
  }

  wrapper.addEventListener('mouseenter', () => showWeatherTooltip(wrapper, data));
  wrapper.addEventListener('mouseleave', hideWeatherTooltip);
  spanEl.appendChild(wrapper);
}

// ─── View injection ───────────────────────────────────────────────────────────

function injectMonthView() {
  document.querySelectorAll('td[data-date]').forEach(td => {
    const dateStr = td.getAttribute('data-date');
    const data = forecastCache[dateStr];
    if (!data) return;
    const container = td.querySelector('[class*="_container_1il6b_"]');
    if (!container) return;
    const numSpan = container.querySelector('span[data-highlighted]');
    if (!numSpan) return;
    const anchor = td.querySelector('a.fc-daygrid-day-number');
    if (anchor) anchor.removeAttribute('title');
    injectWeatherBadge(numSpan, dateStr, data);
  });
}

function injectWeekView() {
  document.querySelectorAll('div[aria-label]').forEach(header => {
    const label = header.getAttribute('aria-label');
    const match = label && label.match(/^(\w+) (\w+) (\d+) (\d{4})$/);
    if (!match) return;
    const [, , month, day, year] = match;
    const months = { January:'01',February:'02',March:'03',April:'04',May:'05',June:'06',July:'07',August:'08',September:'09',October:'10',November:'11',December:'12' };
    const m = months[month];
    if (!m) return;
    const dateStr = `${year}-${m}-${day.padStart(2,'0')}`;
    const data = forecastCache[dateStr];
    if (!data) return;
    const wideSpan = header.querySelector('[class*="_wide_"] [class*="_container_11uvo_"]');
    if (!wideSpan) return;
    injectWeatherBadge(wideSpan, dateStr, data);
  });
}

function injectDayView() {
  const title = document.title;
  const match = title.match(/(\w+), (\w+) (\d+), (\d{4})/);
  if (!match) return;
  const [, , month, day, year] = match;
  const months = { January:'01',February:'02',March:'03',April:'04',May:'05',June:'06',July:'07',August:'08',September:'09',October:'10',November:'11',December:'12' };
  const m = months[month];
  if (!m) return;
  const dateStr = `${year}-${m}-${day.padStart(2,'0')}`;
  const data = forecastCache[dateStr];
  if (!data) return;
  const dayHeader = document.querySelector('[class*="_dayViewDateHeader_"]');
  if (!dayHeader) return;
  const span = dayHeader.querySelector('[class*="_container_11uvo_"]');
  if (!span) return;
  injectWeatherBadge(span, dateStr, data);
}

// ─── Current conditions widget ────────────────────────────────────────────────

function findToolbarContainer() {
  const radioGroup = document.querySelector('[role="radiogroup"] input[value="month"]');
  if (!radioGroup) return null;
  let el = radioGroup.closest('[role="radiogroup"]')?.parentElement;
  while (el && el.tagName !== 'BODY') {
    if (el.querySelector('[role="radiogroup"] input[value="month"]') &&
        el.querySelector('[role="radiogroup"] input[value="week"]') &&
        el.querySelector('[role="radiogroup"] input[value="day"]')) return el;
    el = el.parentElement;
  }
  return null;
}

function renderCurrentWidget(conditions, style) {
  const icons = resolveWeatherIcons(conditions.shortForecast, conditions.rain);
  const container = findToolbarContainer();
  if (!container) return;

  const existing = container.querySelector('#jpp-weather-current');
  if (existing) existing.remove();

  const widget = document.createElement('div');
  widget.id = 'jpp-weather-current';
  widget.style.cssText = 'display:inline-flex;align-items:center;margin-right:10px;font-size:13px;font-weight:500;color:var(--color-text,#1a1a1a);cursor:default;white-space:nowrap;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;gap:2px;';

  const primaryEl = document.createElement('span');
  primaryEl.textContent = icons.primary;
  widget.appendChild(primaryEl);

  if (icons.secondary) {
    const secondaryEl = document.createElement('span');
    secondaryEl.textContent = icons.secondary;
    secondaryEl.style.opacity = String(icons.secondaryOpacity);
    widget.appendChild(secondaryEl);
  }

  if (style === 'full') {
    const labelEl = document.createElement('span');
    labelEl.style.marginLeft = '3px';
    labelEl.textContent = `${conditions.temp}° ${truncateCondition(conditions.shortForecast)}`;
    widget.appendChild(labelEl);
  } else {
    const tempEl = document.createElement('span');
    tempEl.style.marginLeft = '3px';
    tempEl.textContent = `${conditions.temp}°`;
    widget.appendChild(tempEl);
  }

  widget.addEventListener('mouseenter', () => showCurrentTooltip(widget, conditions));
  widget.addEventListener('mouseleave', hideWeatherTooltip);
  container.insertBefore(widget, container.firstChild);
}

async function fetchAndRenderCurrentConditions() {
  const style = await getConditionsStyle();
  chrome.runtime.sendMessage({ type: 'GET_CURRENT_CONDITIONS' }, (response) => {
    if (chrome.runtime.lastError || !response || response.error) return;
    renderCurrentWidget(response.conditions, style);
  });
}

// ─── Init ─────────────────────────────────────────────────────────────────────

function detectView() {
  const title = document.title || '';
  if (/Schedule, \w+, \w+ \d+, \d{4}/.test(title)) return 'day';
  if (/Schedule, Week of/.test(title)) return 'week';
  if (/Schedule, \w+ \d{4}/.test(title)) return 'month';
  return null;
}

async function runWeatherInjection() {
  await fetchForecast();
  const view = detectView();
  if (!view) return;
  if (view === 'month') injectMonthView();
  else if (view === 'week') injectWeekView();
  else if (view === 'day') injectDayView();
}

function initWeather() {
  let injectTimer = null;
  function scheduleInjection() {
    if (injectTimer) clearTimeout(injectTimer);
    injectTimer = setTimeout(() => {
      runWeatherInjection();
      fetchAndRenderCurrentConditions();
    }, 300);
  }

  const observer = new MutationObserver((mutations) => {
    const relevant = mutations.some(m =>
      m.addedNodes.length > 0 || (m.type === 'attributes' && m.attributeName === 'data-date')
    );
    if (relevant) scheduleInjection();
  });

  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-date'] });

  const titleEl = document.querySelector('title');
  if (titleEl) new MutationObserver(() => scheduleInjection()).observe(titleEl, { childList: true });

  runWeatherInjection();
  fetchAndRenderCurrentConditions();

  if (currentConditionsInterval) clearInterval(currentConditionsInterval);
  currentConditionsInterval = setInterval(fetchAndRenderCurrentConditions, 30 * 60 * 1000);
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'REFRESH_CURRENT_CONDITIONS') fetchAndRenderCurrentConditions();
});
