// popup.js — Jobber++ unified popup

const isMac = navigator.platform.toUpperCase().includes('MAC');
const WARNING_THRESHOLD = 10;

// ─── State ────────────────────────────────────────────────────────────────────
let pendingPreset = null;
let activeDropdown = null;
let editingPresetId = null;
let dragSrcId = null;

// ─── Boot ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  initTabs();
  initStatusDot();
  initPresetsTab();
  initShortcutsTab();
  initWeatherTab();
  document.addEventListener('click', closeDropdownOnOutsideClick);
});

// ─── Tabs ─────────────────────────────────────────────────────────────────────
function initTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
      tab.classList.add('active');
      document.getElementById(`tab-${tab.dataset.tab}`).classList.remove('hidden');
    });
  });
}

// ─── Status dot ───────────────────────────────────────────────────────────────
function initStatusDot() {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    const onJobber = tab?.url?.includes('secure.getjobber.com');
    const dot = document.getElementById('statusDot');
    if (onJobber) dot.classList.add('active');
  });
}

// ═══════════════════════════════════════════════════════════
// PRESETS TAB
// ═══════════════════════════════════════════════════════════

function initPresetsTab() {
  renderPresetList();
  bindPresetsFooter();
  bindPresetsDialogs();
}

async function renderPresetList() {
  const presets = await getPresets();
  const list = document.getElementById('preset-list');
  const empty = document.getElementById('presets-empty');
  const warning = document.getElementById('presets-warning');

  list.innerHTML = '';
  empty.classList.toggle('hidden', presets.length > 0);
  warning.classList.toggle('hidden', presets.length <= WARNING_THRESHOLD);

  presets.forEach(preset => list.appendChild(createPresetItem(preset)));
}

function createPresetItem(preset) {
  const li = document.createElement('li');
  li.className = 'preset-item';
  li.dataset.id = preset.id;
  li.draggable = true;

  const handle = document.createElement('span');
  handle.className = 'drag-handle';
  handle.textContent = '⠿';
  handle.title = 'Drag to reorder';

  const name = document.createElement('span');
  name.className = 'preset-name';
  name.textContent = preset.name;
  name.title = preset.url;

  const badge = document.createElement('span');
  badge.className = 'preset-type-badge';
  badge.textContent = preset.isHistorical ? '📅' : '🔄';
  badge.title = preset.isHistorical ? 'Fixed date' : 'Always today';

  const menuBtn = document.createElement('button');
  menuBtn.className = 'preset-menu-btn';
  menuBtn.textContent = '···';
  menuBtn.addEventListener('click', (e) => { e.stopPropagation(); togglePresetsDropdown(preset.id, menuBtn); });

  li.append(handle, name, badge, menuBtn);
  li.addEventListener('dragstart', onDragStart);
  li.addEventListener('dragover', onDragOver);
  li.addEventListener('drop', onDrop);
  li.addEventListener('dragend', onDragEnd);
  return li;
}

// Dropdown
function togglePresetsDropdown(presetId, anchor) {
  closeActiveDropdown();
  const menu = document.createElement('div');
  menu.className = 'dropdown-menu';
  menu.id = 'active-dropdown';

  const editBtn = document.createElement('button');
  editBtn.className = 'dropdown-item';
  editBtn.textContent = '✏️  Edit';
  editBtn.addEventListener('click', () => { closeActiveDropdown(); openEditDialog(presetId); });

  const delBtn = document.createElement('button');
  delBtn.className = 'dropdown-item danger';
  delBtn.textContent = '🗑  Delete';
  delBtn.addEventListener('click', async () => {
    closeActiveDropdown();
    await deletePreset(presetId);
    await renderPresetList();
    notifyContentScript();
  });

  menu.append(editBtn, delBtn);
  const rect = anchor.getBoundingClientRect();
  const popupRect = document.querySelector('.popup').getBoundingClientRect();
  menu.style.top = (rect.bottom - popupRect.top + 2) + 'px';
  document.querySelector('.popup').appendChild(menu);
  activeDropdown = menu;
}

function closeActiveDropdown() {
  activeDropdown?.remove();
  activeDropdown = null;
}

function closeDropdownOnOutsideClick(e) {
  if (activeDropdown && !activeDropdown.contains(e.target)) closeActiveDropdown();
}

// Footer
function bindPresetsFooter() {
  document.getElementById('save-btn').addEventListener('click', onSaveCurrentView);
}

async function onSaveCurrentView() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url?.includes('secure.getjobber.com/schedule')) {
    const btn = document.getElementById('save-btn');
    const orig = btn.innerHTML;
    btn.innerHTML = '⚠️ Navigate to a schedule view first';
    btn.disabled = true;
    setTimeout(() => { btn.innerHTML = orig; btn.disabled = false; }, 2500);
    return;
  }
  const url = tab.url;
  if (hasStaticDate(url)) {
    pendingPreset = { rawUrl: url };
    showDialog('date-dialog');
  } else {
    pendingPreset = { url, isHistorical: false };
    openNameDialog(url);
  }
}

// Dialogs
function bindPresetsDialogs() {
  document.getElementById('dialog-today').addEventListener('click', () => {
    const url = substituteToday(pendingPreset.rawUrl);
    pendingPreset = { url, isHistorical: false };
    hideDialog('date-dialog');
    openNameDialog(url);
  });

  document.getElementById('dialog-historical').addEventListener('click', () => {
    pendingPreset = { url: pendingPreset.rawUrl, isHistorical: true };
    hideDialog('date-dialog');
    openNameDialog(pendingPreset.url);
  });

  document.getElementById('name-cancel').addEventListener('click', () => { hideDialog('name-dialog'); pendingPreset = null; });
  document.getElementById('name-save').addEventListener('click', onNameSave);
  document.getElementById('name-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') onNameSave();
    if (e.key === 'Escape') { hideDialog('name-dialog'); pendingPreset = null; }
  });

  document.getElementById('edit-cancel').addEventListener('click', () => { hideDialog('edit-dialog'); editingPresetId = null; });
  document.getElementById('edit-save').addEventListener('click', onEditSave);
}

function openNameDialog(url) {
  const input = document.getElementById('name-input');
  input.value = generatePresetName(url);
  document.getElementById('url-preview').textContent = url;
  showDialog('name-dialog');
  input.focus();
  input.select();
}

async function onNameSave() {
  const name = document.getElementById('name-input').value.trim();
  if (!name) return;
  await addPreset({ name, url: pendingPreset.url, isHistorical: pendingPreset.isHistorical });
  pendingPreset = null;
  hideDialog('name-dialog');
  await renderPresetList();
  notifyContentScript();
}

async function openEditDialog(presetId) {
  const presets = await getPresets();
  const preset = presets.find(p => p.id === presetId);
  if (!preset) return;
  editingPresetId = presetId;
  document.getElementById('edit-name').value = preset.name;
  document.getElementById('edit-url').value = preset.url;
  showDialog('edit-dialog');
  document.getElementById('edit-name').focus();
}

async function onEditSave() {
  const name = document.getElementById('edit-name').value.trim();
  const url = document.getElementById('edit-url').value.trim();
  if (!name || !url) return;
  await updatePreset(editingPresetId, { name, url, isHistorical: hasStaticDate(url) });
  editingPresetId = null;
  hideDialog('edit-dialog');
  await renderPresetList();
  notifyContentScript();
}

// Drag reorder
function onDragStart(e) { dragSrcId = e.currentTarget.dataset.id; e.currentTarget.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; }
function onDragOver(e) { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; }
async function onDrop(e) {
  e.preventDefault();
  const targetId = e.currentTarget.dataset.id;
  if (!dragSrcId || dragSrcId === targetId) return;
  const presets = await getPresets();
  const ids = presets.map(p => p.id);
  const si = ids.indexOf(dragSrcId), ti = ids.indexOf(targetId);
  ids.splice(si, 1); ids.splice(ti, 0, dragSrcId);
  await reorderPresets(ids);
  await renderPresetList();
  notifyContentScript();
}
function onDragEnd(e) { e.currentTarget.classList.remove('dragging'); dragSrcId = null; }

// Dialog helpers
function showDialog(id) { document.getElementById(id).classList.remove('hidden'); }
function hideDialog(id) { document.getElementById(id).classList.add('hidden'); }

async function notifyContentScript() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.url?.includes('secure.getjobber.com')) {
    chrome.tabs.sendMessage(tab.id, { type: 'REFRESH_TOOLBAR' }).catch(() => {});
  }
}

// ═══════════════════════════════════════════════════════════
// SHORTCUTS TAB
// ═══════════════════════════════════════════════════════════

function initShortcutsTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    const onJobber = tab?.url?.includes('secure.getjobber.com');
    const onSchedule = tab?.url?.includes('secure.getjobber.com/schedule');

    if (!onJobber) {
      document.getElementById('shortcuts-not-jobber').classList.remove('hidden');
      document.getElementById('shortcuts-content').classList.add('hidden');
      return;
    }

    const shortcuts = window.JPP_SHORTCUTS || {};
    const global = Object.entries(shortcuts).filter(([, s]) => s.scope === 'global');
    const schedule = Object.entries(shortcuts).filter(([, s]) => s.scope === 'schedule');

    renderShortcutGroup(global, document.getElementById('shortcuts-global'));
    renderShortcutGroup(schedule, document.getElementById('shortcuts-schedule'));

    if (!onSchedule) {
      document.getElementById('shortcuts-schedule').classList.add('dimmed');
      document.getElementById('shortcuts-schedule-note').classList.remove('hidden');
    }
  });
}

function renderShortcutGroup(entries, container) {
  entries.forEach(([, s]) => {
    const keys = isMac ? s.keys : s.keysWin;
    const keyParts = keys.split(/\s*\+\s*/).map(k => k.trim()).filter(Boolean);
    const row = document.createElement('div');
    row.className = 'shortcut-row';
    row.innerHTML = `
      <div class="shortcut-info">
        <div class="shortcut-name">${s.label}</div>
        <div class="shortcut-desc">${s.description}</div>
      </div>
      <div class="keys">
        ${keyParts.map(k => `<kbd>${k}</kbd>`).join('<span style="color:#9ca3af;font-size:10px;margin:0 1px">+</span>')}
      </div>
    `;
    container.appendChild(row);
  });
}

// ═══════════════════════════════════════════════════════════
// WEATHER TAB
// ═══════════════════════════════════════════════════════════

function initWeatherTab() {
  const cityInput  = document.getElementById('cityInput');
  const btnSave    = document.getElementById('btnSave');
  const btnClear   = document.getElementById('btnClear');
  const statusEl   = document.getElementById('weatherStatus');
  const locValue   = document.getElementById('weather-loc-value');

  // Load current location
  chrome.storage.local.get('weatherLocation', (result) => {
    locValue.textContent = result.weatherLocation?.label || 'Not set';
  });

  // Load style toggle
  chrome.storage.local.get('conditionsStyle', (result) => {
    setActiveStyle(result.conditionsStyle || 'compact');
  });

  btnSave.addEventListener('click', () => {
    const city = cityInput.value.trim();
    if (!city) { setWeatherStatus('Please enter a city name.', 'err'); return; }
    btnSave.disabled = true;
    setWeatherStatus('Looking up location…', '');
    chrome.runtime.sendMessage({ type: 'SAVE_CITY', city }, (response) => {
      btnSave.disabled = false;
      if (chrome.runtime.lastError || response?.error) {
        setWeatherStatus(response?.error || 'Extension error. Try reloading.', 'err');
        return;
      }
      cityInput.value = '';
      locValue.textContent = response.loc.label;
      setWeatherStatus('Saved! Reload Jobber to apply.', 'ok');
    });
  });

  btnClear.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'CLEAR_LOCATION' }, () => {
      locValue.textContent = 'Not set';
      cityInput.value = '';
      setWeatherStatus('Location cleared.', 'ok');
    });
  });

  cityInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') btnSave.click(); });

  document.getElementById('styleCompact').addEventListener('click', () => saveStyle('compact'));
  document.getElementById('styleFull').addEventListener('click', () => saveStyle('full'));

  function setWeatherStatus(msg, type) {
    statusEl.textContent = msg;
    statusEl.className = 'status-msg ' + type;
  }

  function setActiveStyle(style) {
    document.getElementById('styleCompact').classList.toggle('active', style === 'compact');
    document.getElementById('styleFull').classList.toggle('active', style === 'full');
  }

  function saveStyle(style) {
    chrome.storage.local.set({ conditionsStyle: style }, () => {
      setActiveStyle(style);
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: 'REFRESH_CURRENT_CONDITIONS' }).catch(() => {});
      });
    });
  }
}
